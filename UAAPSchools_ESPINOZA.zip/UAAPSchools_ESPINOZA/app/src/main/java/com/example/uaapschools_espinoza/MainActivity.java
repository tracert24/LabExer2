package com.example.uaapschools_espinoza;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    EditText school1, school2, school3, school4,school5, school6,school7, school8;
    SharedPreferences sp;

    @Override
    protected void onCreate(Bundle savedInstanceState) {


        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        school1 = findViewById(R.id.school_1);
        school2 = findViewById(R.id.school_2);
        school3 = findViewById(R.id.school_3);
        school4 = findViewById(R.id.school_4);
        school5 = findViewById(R.id.school_5);
        school6 = findViewById(R.id.school_4);
        school7 = findViewById(R.id.school_7);
        school8 = findViewById(R.id.school_8);
    }

    public void saveData (View v){
        sp = getSharedPreferences("data1", MODE_PRIVATE);
        SharedPreferences.Editor editor = sp.edit();
        String s1 = school1.getText().toString();
        String s2 = school2.getText().toString();
        String s3 = school3.getText().toString();
        String s4 = school4.getText().toString();
        String s5 = school5.getText().toString();
        String s6 = school6.getText().toString();
        String s7 = school7.getText().toString();
        String s8 = school8.getText().toString();

        editor.putString("school1", s1);
        editor.putString("school2", s2);
        editor.putString("school3", s3);
        editor.putString("school4", s4);
        editor.putString("school5", s5);
        editor.putString("school6", s6);
        editor.putString("school7", s7);
        editor.putString("school8", s8);
        editor.commit();
        Toast.makeText(this, "Data was saved.", Toast.LENGTH_LONG).show();
    }

    public void nextPage(View view){
        Intent intent = new Intent(this, SchoolVerify.class);
        startActivity(intent);
    }


}
