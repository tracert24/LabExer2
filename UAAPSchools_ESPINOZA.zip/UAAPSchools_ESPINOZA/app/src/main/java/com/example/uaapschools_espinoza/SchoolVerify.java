package com.example.uaapschools_espinoza;

import androidx.appcompat.app.AppCompatActivity;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class SchoolVerify extends AppCompatActivity {
    EditText uni2, uni3, uni4, uni5, uni6, uni7, uni8,inSchool;
    SharedPreferences sp;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_school_verify);
        inSchool =findViewById(R.id.inSchool);
    }

    public void display (View v){
        sp = getSharedPreferences("data1", MODE_PRIVATE);
        String uni1SP = sp.getString("school1", null);
        String uni2SP = sp.getString("school2", null);
        String uni3SP = sp.getString("school3", null);
        String uni4SP = sp.getString("school4", null);
        String uni5SP = sp.getString("school5", null);
        String uni6SP = sp.getString("school6", null);
        String uni7SP = sp.getString("school7", null);
        String uni8SP = sp.getString("school8", null);



        if(uni1SP.equals(inSchool.getText().toString()) || uni2SP.equals(inSchool.getText().toString()) || uni3SP.equals(inSchool.getText().toString()) || uni4SP.equals(inSchool.getText().toString()) || uni5SP.equals(inSchool.getText().toString()) || uni6SP.equals(inSchool.getText().toString()) || uni7SP.equals(inSchool.getText().toString()) || uni8SP.equals(inSchool.getText().toString())) {
            Toast.makeText(this, "School is competing in the UAAP", Toast.LENGTH_LONG).show();
        }   else{
            Toast.makeText(this, "School is not competing in the UAAP",Toast.LENGTH_LONG).show();

        }

    }
}
